<html>
<body>


<h2>Data Inserted</h2>

<h3>Name&nbsp;&nbsp;&nbsp;&nbsp;Address&nbsp;&nbsp;&nbsp;&nbsp;Store</h3>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "testdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

//select
$sql = "SELECT name, address,store FROM exercise2_sql";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "" . $row["name"]. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $row["address"]. "&nbsp;&nbsp;&nbsp;&nbsp;" . $row["store"]. "<br>";
  }
} else {
  echo "0 results";
}
//select

$conn->close();
?>
<br>
<a href="formDBSec2.html">Return to Form</a>
</body>
</html>