<html>
<body>
<?php 
$name = $address = $store = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = test_input($_POST["name"]);
  $address = test_input($_POST["address"]);
  $store = test_input($_POST["store"]);
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
  }
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "testdb";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "INSERT INTO exercise2_sql (name, address, store)
  VALUES ('".$_POST["name"]."','".$_POST["address"]."','".$_POST["store"]."' )";

  if ($conn->query($sql) === TRUE) {
    echo "";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  

  ?>




<?php
echo "<br>";
echo "Welcome ";
echo $name;
echo "<br>";
echo "Your address is :";
echo $address;
echo "<br>";
echo "Your favorite store is :";
echo $store;
echo "<br>";
echo "<br>";
echo "database insertion";
echo "<br>";
echo "A record for name and address and store have been inserted";
echo "<br>";
?>


<a href="formDBSec2.html">Home Site</a>
</body>
</html>